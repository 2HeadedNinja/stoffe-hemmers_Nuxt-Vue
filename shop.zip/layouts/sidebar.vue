<template>
  <div class="layout__sidebar grid">
    <AppHeader>
      AppHeader
    </AppHeader>
    <transition name="fade">
      <div v-show="show !== null" class="layout__sidebar-scrollcontent">
        <div class="grid content" style="--grid-template: auto / repeat(25,1fr); --grid-gap: 40px; --padding-top: 40px; --padding-bottom: 40px;">
          <aside style="--grid-column: span 7;">
            Sidebar
          </aside>
          <nuxt />
        </div>
        <AppFooter></AppFooter>
      </div>
    </transition>
  </div>
</template>

<script>
  import AppHeader from '~/components/AppHeader'
  import AppFooter from '~/components/AppFooter'

  export default {
    name        : 'LayoutSidebar',
    components  : {
      AppHeader,
      AppFooter
    },

    methods     : {
      positionScrollContent() {
        this.$root.$on('AppHeaderMounted',event => {
          if(event.height !== null) {
            const __scrollcontent = this.$el.querySelector('.layout__sidebar-scrollcontent');

            if(__scrollcontent !== null) {
              let __style = '--margin-top: '+event.height+'px;';

              if(__scrollcontent.hasAttribute('style')) {
                __style += ' '+__scrollcontent.getAttribute('style');
              }

              __scrollcontent.setAttribute('style',__style);
            }
            
            this.$data.show = true;

            setTimeout(() => {
              this.$root.$emit('LayoutReady');
            },50);
          }
        });
      }
    },

    data() {
      return {
        show : null
      }
    },

    created() {
      this.positionScrollContent();
    },

    mounted() {
    }
  }
</script>