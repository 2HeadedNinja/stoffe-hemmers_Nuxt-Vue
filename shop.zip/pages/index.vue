<template>
  <main style="background-color: #00ffff;">
    index
  </main>
</template>

<script>
export default {
  layout : 'default'
}
</script>
