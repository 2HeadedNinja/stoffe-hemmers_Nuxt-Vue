import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5904f0ba = () => interopDefault(import('..\\pages\\category\\_id.vue' /* webpackChunkName: "pages_category__id" */))
const _151bdc90 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
      path: "/category/:id?",
      component: _5904f0ba,
      name: "category-id___de"
    }, {
      path: "/nl/category/:id?",
      component: _5904f0ba,
      name: "category-id___nl"
    }, {
      path: "/",
      component: _151bdc90,
      name: "index___de"
    }, {
      path: "/nl/",
      component: _151bdc90,
      name: "index___nl"
    }],

  fallback: false
}

export function createRouter() {
  return new Router(routerOptions)
}
