<template>
  <footer>
    AppFooter
  </footer>
</template>

<script>
  export default {
    name : 'AppFooter',

    created() {

    },

    mounted() {
      
    }
  }
</script>