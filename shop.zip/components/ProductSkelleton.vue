<template>
  <div class="product__card-skelleton" style="--grid-column: span 1;">
    <div class="product__card-skelleton__image"></div>
    <div class="product__card-skelleton__button"></div>
    <div class="product__card-skelleton__flags"></div>
    <div class="product__card-skelleton__other"></div>
  </div>
</template>

<script>
  export default {
    name : 'ProductSkelleton'
  }
</script>