<template>

</template>

<script>
  export default {
    name : 'AppImage'
    // -> https://markus.oberlehner.net/blog/lazy-loading-responsive-images-with-vue/
  }
</script>